package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

class SketchParams(
    val mode: Int,    // 0 pensil hitam-putih, 1 pensil berwarna, 2 garis tegas
    val blur: Int,    // 0..100 ketebalan/kehalusan garis
    val dark: Int,    // 0..100 kegelapan / kekuatan garis
    val color: Int,   // 0..100 kekuatan warna (mode 1)
    val grain: Int,   // 0..100 tekstur kertas
    val paper: Int    // 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)
)

object Sketcher {
    fun render(src: Bitmap, p: SketchParams): Bitmap {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val scale = max(w, h) / 900f
        val gray = IntArray(n) {
            val c = px[it]
            (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        }
        val v = IntArray(n)

        if (p.mode == 2) {
            java.util.Arrays.fill(v, 255)
            val g = gray.copyOf()
            boxBlur(g, w, h, max(1, ((1f + p.blur * 0.12f) * scale).roundToInt()))
            val gain = 1.5f + p.dark * 0.06f
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
                val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
                v[i] = 255 - min(255, ((abs(gx) + abs(gy)) * gain / 2f).toInt())
            }
        } else {
            // Color dodge: gambar / (kebalikan gambar yang di-blur)
            val inv = IntArray(n) { 255 - gray[it] }
            boxBlur(inv, w, h, max(1, ((2f + p.blur * 0.38f) * scale).roundToInt()))
            val gamma = 0.6 + p.dark / 100.0 * 1.4
            val lut = IntArray(256) { (255.0 * (it / 255.0).pow(gamma)).roundToInt().coerceIn(0, 255) }
            for (i in 0 until n) {
                val d = 256 - inv[i]
                v[i] = lut[min(255, gray[i] * 256 / max(1, d))]
            }
        }

        val out = IntArray(n)
        val colored = p.mode == 1
        val kc = p.color / 100f
        val gr = p.grain / 100f
        val pr: Float
        val pg: Float
        val pb: Float
        when (p.paper) {
            1 -> { pr = 245f; pg = 236f; pb = 215f }
            else -> { pr = 255f; pg = 255f; pb = 255f }
        }
        for (i in 0 until n) {
            val noise = ((i * -1640531535) ushr 24) / 255f
            val vv = v[i] * (1f - gr * 0.25f * noise)
            var lr = 255f
            var lg = 255f
            var lb = 255f
            if (colored) {
                val c = px[i]
                lr = 255f * (1f - kc) + Color.red(c) * kc
                lg = 255f * (1f - kc) + Color.green(c) * kc
                lb = 255f * (1f - kc) + Color.blue(c) * kc
            }
            if (p.paper == 3) {
                val al = (255f - vv).toInt().coerceIn(0, 255)
                out[i] = if (colored) Color.argb(al, (lr * 0.5f).toInt().coerceIn(0, 255), (lg * 0.5f).toInt().coerceIn(0, 255), (lb * 0.5f).toInt().coerceIn(0, 255))
                else Color.argb(al, 20, 20, 24)
                continue
            }
            val r: Float
            val g: Float
            val b: Float
            if (p.paper == 2) {
                val t = (255f - vv) / 255f
                r = 43f + (lr - 43f) * t
                g = 58f + (lg - 58f) * t
                b = 51f + (lb - 51f) * t
            } else {
                r = vv * lr / 255f * pr / 255f
                g = vv * lg / 255f * pg / 255f
                b = vv * lb / 255f * pb / 255f
            }
            out[i] = Color.rgb(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Blur kotak 3x (mendekati Gaussian), tepi di-clamp. */
    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(max(w, h))
        val k = 2 * r + 1
        repeat(3) {
            for (y in 0 until h) {
                val o = y * w
                var sum = 0
                for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[x] = sum / k
                    sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
                }
                System.arraycopy(tmp, 0, a, o, w)
            }
            for (x in 0 until w) {
                var sum = 0
                for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    tmp[y] = sum / k
                    sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
                }
                for (y in 0 until h) a[y * w + x] = tmp[y]
            }
        }
    }
}
