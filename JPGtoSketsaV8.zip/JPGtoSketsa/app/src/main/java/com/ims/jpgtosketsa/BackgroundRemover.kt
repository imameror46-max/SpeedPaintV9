package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Penghapus latar belakang (langkah 2).
 * - Utama: ML Kit Subject Segmentation (berjalan di HP, mengenali objek apa saja).
 * - Cadangan: deteksi warna latar dari tepi foto (cocok untuk latar polos) bila ML Kit tidak tersedia.
 */
object BackgroundRemover {
    /** a = tingkat keyakinan objek 0..1 per piksel, ukuran w x h. */
    class Mask(val w: Int, val h: Int, val a: FloatArray, val fallback: Boolean)

    /** Hanya boleh dipanggil dari thread latar (menunggu hasil ML Kit). */
    fun detect(src: Bitmap): Mask {
        val w = src.width
        val h = src.height
        try {
            val opts = SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
            val seg = SubjectSegmentation.getClient(opts)
            try {
                val res = Tasks.await(seg.process(InputImage.fromBitmap(src, 0)), 120, TimeUnit.SECONDS)
                val buf = res.foregroundConfidenceMask
                if (buf != null) {
                    val arr = FloatArray(w * h)
                    buf.rewind()
                    buf.get(arr, 0, min(arr.size, buf.remaining()))
                    var fg = 0
                    for (v in arr) if (v > 0.5f) fg++
                    // Bila tidak ada objek terdeteksi sama sekali, coba cadangan
                    if (fg.toFloat() / arr.size > 0.005f) return Mask(w, h, arr, false)
                }
            } finally {
                seg.close()
            }
        } catch (e: Throwable) {
            // lanjut ke cadangan
        }
        return colorMask(src)
    }

    /** Cadangan: warna latar diambil dari tepi gambar, lalu di-flood-fill ke dalam. */
    private fun colorMask(src: Bitmap): Mask {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val border = IntArray(2 * (w + h))
        var k = 0
        for (x in 0 until w) { border[k++] = x; border[k++] = (h - 1) * w + x }
        for (y in 0 until h) { border[k++] = y * w; border[k++] = y * w + w - 1 }

        var sr = 0L
        var sg = 0L
        var sb = 0L
        for (i in border) { val c = px[i]; sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c) }
        val mr = (sr / border.size).toInt()
        val mg = (sg / border.size).toInt()
        val mb = (sb / border.size).toInt()
        var dev = 0L
        for (i in border) {
            val c = px[i]
            dev += abs(Color.red(c) - mr) + abs(Color.green(c) - mg) + abs(Color.blue(c) - mb)
        }
        val tol = (40 + (dev / border.size).toInt() * 2).coerceIn(40, 140)

        fun near(i: Int): Boolean {
            val c = px[i]
            return abs(Color.red(c) - mr) + abs(Color.green(c) - mg) + abs(Color.blue(c) - mb) <= tol
        }

        val isBg = BooleanArray(n)
        val queue = IntArray(n)
        var qh = 0
        var qt = 0
        for (i in border) if (!isBg[i] && near(i)) { isBg[i] = true; queue[qt++] = i }
        while (qh < qt) {
            val i = queue[qh++]
            val x = i % w
            val y = i / w
            if (x > 0) { val j = i - 1; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
            if (x < w - 1) { val j = i + 1; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
            if (y > 0) { val j = i - w; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
            if (y < h - 1) { val j = i + w; if (!isBg[j] && near(j)) { isBg[j] = true; queue[qt++] = j } }
        }
        val a = FloatArray(n) { if (isBg[it]) 0f else 1f }
        blurF(a, w, h, max(1, max(w, h) / 400))
        return Mask(w, h, a, true)
    }

    /**
     * Terapkan peta objek ke gambar: alpha akhir = alpha gambar x peta.
     * thr 0..100 (naik = potongan lebih ketat), soft 0..100 (naik = tepi lebih lembut).
     * Ukuran peta boleh berbeda dari gambar (disesuaikan).
     */
    fun apply(src: Bitmap, m: Mask, thr: Int, soft: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val t = 0.2f + thr / 100f * 0.6f
        val s = 0.02f + soft / 100f * 0.4f
        val lo = t - s / 2f
        for (y in 0 until h) {
            val my = min(m.h - 1, y * m.h / h)
            for (x in 0 until w) {
                val mx = min(m.w - 1, x * m.w / w)
                val v = m.a[my * m.w + mx]
                var q = ((v - lo) / s).coerceIn(0f, 1f)
                q = q * q * (3f - 2f * q)
                val i = y * w + x
                val c = px[i]
                val na = (Color.alpha(c) * q).toInt().coerceIn(0, 255)
                px[i] = Color.argb(na, Color.red(c), Color.green(c), Color.blue(c))
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Pangkas ke area yang tidak transparan (agar video SpeedPaint tidak banyak ruang kosong). */
    fun cropToContent(src: Bitmap, padPct: Int = 4): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var x0 = w
        var y0 = h
        var x1 = -1
        var y1 = -1
        for (y in 0 until h) for (x in 0 until w) {
            if ((px[y * w + x] ushr 24) > 30) {
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
            }
        }
        if (x1 < 0) return src
        val pad = max(w, h) * padPct / 100
        val cx0 = max(0, x0 - pad)
        val cy0 = max(0, y0 - pad)
        val cx1 = min(w - 1, x1 + pad)
        val cy1 = min(h - 1, y1 + pad)
        val cw = max(2, cx1 - cx0 + 1)
        val ch = max(2, cy1 - cy0 + 1)
        if (cx0 + cw > w || cy0 + ch > h) return src
        return Bitmap.createBitmap(src, cx0, cy0, cw, ch)
    }

    /** Gambar transparan di atas pola kotak-kotak (hanya untuk tampilan pratinjau). */
    fun onChecker(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint()
        val cell = max(8, max(w, h) / 40)
        var yy = 0
        var row = 0
        while (yy < h) {
            var xx = 0
            var col = 0
            while (xx < w) {
                p.color = if ((row + col) % 2 == 0) 0xFFFFFFFF.toInt() else 0xFFD9D9D9.toInt()
                c.drawRect(xx.toFloat(), yy.toFloat(), (xx + cell).toFloat(), (yy + cell).toFloat(), p)
                xx += cell
                col++
            }
            yy += cell
            row++
        }
        c.drawBitmap(src, 0f, 0f, null)
        return out
    }

    private fun blurF(a: FloatArray, w: Int, h: Int, r: Int) {
        val tmp = FloatArray(max(w, h))
        val k = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val o = y * w
            var sum = 0f
            for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[x] = sum / k
                sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
            }
            System.arraycopy(tmp, 0, a, o, w)
        }
        for (x in 0 until w) {
            var sum = 0f
            for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                tmp[y] = sum / k
                sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
            }
            for (y in 0 until h) a[y * w + x] = tmp[y]
        }
    }
}
